import { Controller } from '@nestjs/common';

@Controller('cupos')
export class CuposController {

    /**
     * @param cuposService Inyecta el servicio de cupos
     * 
     */

    constructor() {}

}
